var express = require('express');
var app = express();
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/comp20'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
 });

//home, root
app.get('/', function(request, response) {
  response.set('Content-Type', "text/html");
  var username = request.query.username;
  var table;

  db.collection("scores", function(error, collection){
    collection.find().sort({"score":-1}).toArray(function(error, data){
      if (!error){
        table = "<!DOCTYPE HTML><html>"
              +"<head>" + "<title>2048</title>" + "</head>"
              + "<body>"
              + "<h1>2048 Scoreboard</h1>"
              + "<table>" + "<tr>"
              + "<th>Username</th>" + "<th>Score</th>" + "<th>Time</th>"
              + "</tr>";
        for(var i = 0; i < data.length; i++){
          table += "<tr>"+"<td>"+ data[i].username+"</td>"
                  +"<td>" + data[i].score+"</td>"
                  +"<td>" + data[i].created_at + "</td>" + "</tr>";
      }
        table += "</table>" + "</body>" + "</html>";
      }
      else{
        response.send("Error found!");  
      }

      response.send(table);
    });
  });
});

app.get('/scores.json', function(request, response) {
  response.set('Content-Type', 'text/JSON');
  var username = request.query.username;

  db.collection('scores', function(error, collection) {
      collection.find({"username": username}).sort({"score":-1}).toArray(function(error, data) {
          response.send(JSON.stringify(data));
      });
  });
});

app.post('/submit.json', function(request, response) {
    db.collection('scores', function(error, collection){
        collection.insert(
          {
          "username": request.body.username,
          "score": parseInt(request.body.score),
          "grid": request.body.grid,
          "created_at": request.body.created_at
          },

          function(error, saved) {
            response.send(200);
          });
      });
    });

var port = process.env.PORT || 5000;
app.listen(port, function() {
console.log("Listening on " + port);
});
